<?php

/**
 * @SWG\Info(title="Pasteque API", version="0.1")
 */
